class VacuumWorld: #writen using gemini
    """A vacuum-cleaning robot problem on a rectangular grid."""
    
    # Canonical action order required by spec
    ACTIONS = ['MOVE_UP', 'MOVE_DOWN', 'MOVE_LEFT', 'MOVE_RIGHT', 'CLEAN']
    
    def __init__(self, grid, start, dirty):
        """
        Args:
            grid: List of strings or list of lists; '#' marks an obstacle.
            start: Tuple (row, col) - the robot's starting position.
            dirty: Iterable of (row, col) tuples that begin dirty.
        """
        self.grid = [list(row) for row in grid]
        self.rows = len(self.grid)
        self.cols = len(self.grid[0]) if self.rows > 0 else 0
        self.start = tuple(start)
        self.initial_dirty = frozenset(tuple(d) for d in dirty)

    def initial_state(self):
        """Return the initial state as ((row, col), frozenset(dirty))."""
        return (self.start, self.initial_dirty)

    def is_goal(self, state):
        """Return True if the dirty set in state is empty."""
        pos, dirty_set = state
        return len(dirty_set) == 0

    def get_actions(self, state):
        """
        Return a list of legal action names available in state.
        Legal means: moves stay in bounds and off obstacles, and CLEAN is
        only offered when the robot's current cell is dirty.
        """
        pos, dirty_set = state
        r, c = pos
        legal_actions = []

        # Define potential moves: (action_name, (delta_row, delta_col))
        moves = {
            'MOVE_UP': (-1, 0),
            'MOVE_DOWN': (1, 0),
            'MOVE_LEFT': (0, -1),
            'MOVE_RIGHT': (0, 1)
        }

        for action in self.ACTIONS:
            if action in moves:
                dr, dc = moves[action]
                nr, nc = r + dr, c + dc
                # Check bounds and obstacles
                if 0 <= nr < self.rows and 0 <= nc < self.cols:
                    if self.grid[nr][nc] != '#':
                        legal_actions.append(action)
            elif action == 'CLEAN':
                # CLEAN is only legal if current cell is dirty
                if pos in dirty_set:
                    legal_actions.append(action)

        return legal_actions

    def result(self, state, action):
        """Return the successor state produced by applying action."""
        pos, dirty_set = state
        r, c = pos
        
        if action == 'MOVE_UP':
            new_pos = (r - 1, c)
            return (new_pos, dirty_set)
        elif action == 'MOVE_DOWN':
            new_pos = (r + 1, c)
            return (new_pos, dirty_set)
        elif action == 'MOVE_LEFT':
            new_pos = (r, c - 1)
            return (new_pos, dirty_set)
        elif action == 'MOVE_RIGHT':
            new_pos = (r, c + 1)
            return (new_pos, dirty_set)
        elif action == 'CLEAN':
            # Remove current position from the frozenset immutably
            new_dirty_set = frozenset(d for d in dirty_set if d != pos)
            return (pos, new_dirty_set)
        else:
            raise ValueError(f"Unknown action: {action}")

    def action_cost(self, state, action):
        """Return the cost of action in state (always 1 here)."""
        return 1

    def __str__(self):
        """Render method to print the grid with robot (R) and dirt (D)."""
        pass # Optional helper or use standard string rendering during debug