"""
CS3810 Mini-Project 1 - Part 2: The Search Algorithms (100 points)
==================================================================

Implement dfs_search, astar_search, and idastar_search below. Do not change
the signatures or the return shapes: run_tests.py and the grading harness
unpack them exactly as documented.

You may NOT use a library implementation of DFS, A*, or IDA* (networkx,
simpleai, aima-python, ...). Using heapq, collections.deque, and the
provided PriorityQueue is expected and fine.

Metric definitions - use these, and say which you used in your report:

    nodes_expanded      A node is EXPANDED when it is removed from the
                        frontier and its successors are generated. Do not
                        count nodes that were merely generated.

    max_frontier_size   The largest number of live entries the frontier
                        ever held. For the PriorityQueue helper this is
                        len(queue), not len(queue.heap).

    iterations          (IDA* only) The number of depth-limited passes,
                        i.e. how many times the f-cost threshold was set.
                        A search that succeeds on the first threshold has
                        iterations == 1.

Suggested order of work: DFS first, then A*, then IDA*.
"""

import math

from priority_queue import PriorityQueue

# Sentinel used by the IDA* recursion to report success. Returning a plain
# number means "the smallest f-value I saw above the threshold".
FOUND = 'FOUND'


def dfs_search(problem):#writen using gemini
    """
    Perform Depth-First Search.

    Args:
        problem: VacuumWorld instance

    Returns:
        Tuple (solution_path, nodes_expanded, max_frontier_size)
        solution_path: List of actions, or None if no solution
        nodes_expanded: Number of nodes expanded during search
        max_frontier_size: Maximum size of frontier during search

    Requirements:
        * Iterative, with an explicit stack. Do NOT recurse - you will hit
          Python's recursion limit on the larger grids.
        * Cycle detection with an explored set, or DFS will not terminate.
        * Returns the FIRST solution found. It will not be optimal, and it
          is not supposed to be.

    Hint: push (state, path_so_far) pairs. Push successors in reversed()
    order if you want the stack to explore them in ACTION_ORDER order.
    """
    initial_state = problem.initial_state()
    
    # Stack stores tuples of (current_state, list_of_actions)
    stack = [(initial_state, [])]
    explored = set()
    
    nodes_expanded = 0
    max_frontier_size = len(stack)
    
    while stack:
        max_frontier_size = max(max_frontier_size, len(stack))
        current_state, path = stack.pop()
        
        # Check if goal
        if problem.is_goal(current_state):
            return path, nodes_expanded, max_frontier_size
            
        if current_state not in explored:
            explored.add(current_state)
            nodes_expanded += 1
            
            # Iterate through legal actions in canonical order
            for action in problem.get_actions(current_state):
                successor = problem.result(current_state, action)
                if successor not in explored:
                    stack.append((successor, path + [action]))
                    
    # If we get here, no path was found
    return None, nodes_expanded, max_frontier_size

def astar_search(problem, heuristic):#writen using gemini
    """
    Perform A* Search.

    Args:
        problem: VacuumWorld instance
        heuristic: Function h(state, problem) -> estimated cost to goal

    Returns:
        Tuple (solution_path, nodes_expanded, max_frontier_size)

    Requirements:
        * Priority queue ordered by f(n) = g(n) + h(n).
        * Handle REOPENING: if you find a cheaper path to a state you have
          already expanded, you must be able to improve it. The provided
          PriorityQueue supports this - pushing an item already in the
          queue replaces its priority instead of duplicating it.
        * With an admissible heuristic this MUST return an optimal
          solution. run_tests.py checks that against known optimal costs.

    Hint: keep a dict g[state] of best-known cost-so-far and a dict
    came_from[state] = (parent_state, action) to rebuild the path at the
    end. A helper like _reconstruct() below keeps the main loop readable.
    """
    initial_state = problem.initial_state()
    pq = PriorityQueue()
    
    # Track the cheapest g-score and the path to reach each state
    g_scores = {initial_state: 0}
    paths = {initial_state: []}
    
    initial_f = g_scores[initial_state] + heuristic(initial_state, problem)
    pq.push(initial_state, initial_f)
    
    explored = set()
    nodes_expanded = 0
    max_frontier_size = len(pq)
    
    while len(pq) > 0:
        max_frontier_size = max(max_frontier_size, len(pq))
        current_state = pq.pop()
        
        if problem.is_goal(current_state):
            return paths[current_state], nodes_expanded, max_frontier_size
            
        if current_state in explored:
            continue
            
        explored.add(current_state)
        nodes_expanded += 1
        
        current_g = g_scores[current_state]
        current_path = paths[current_state]
        
        for action in problem.get_actions(current_state):
            successor = problem.result(current_state, action)
            
            if successor in explored:
                continue
                
            tentative_g = current_g + problem.action_cost(current_state, action)
            
            # If we found a cheaper path to the successor, update tracking and queue
            if successor not in g_scores or tentative_g < g_scores[successor]:
                g_scores[successor] = tentative_g
                paths[successor] = current_path + [action]
                f_val = tentative_g + heuristic(successor, problem)
                pq.push(successor, f_val)
                
    return None, nodes_expanded, max_frontier_size

def _reconstruct(came_from, state):
    """Walk came_from backwards from `state` and return the action list.

    Args:
        came_from: Dict mapping state -> (parent_state, action)
        state: The goal state reached by the search

    Returns:
        List of actions from the initial state to `state`.
    """
    raise NotImplementedError("Part 2b: implement _reconstruct (optional helper)")


def idastar_search(problem, heuristic): #writen using gemini
    """
    Perform Iterative Deepening A* Search.

    Args:
        problem: VacuumWorld instance
        heuristic: Function h(state, problem) -> estimated cost to goal

    Returns:
        Tuple (solution_path, nodes_expanded, iterations)
        iterations: Number of depth-limited iterations performed

    Requirements:
        * Iterative deepening on an f-cost THRESHOLD, not on depth. The
          next threshold is the smallest f-value that exceeded the current
          one.
        * Linear space: no explored set carried across iterations. You may
          track the states on the current path to avoid immediate cycles.
        * Returns an optimal solution.

    Structure that works (write DFS and A* first - this will make far more
    sense once you have both):

        threshold = h(start)
        loop:
            result = search(start, g=0, threshold)
            if result is FOUND:    return the path
            if result is infinite: return None (no solution)
            threshold = result

    where search(state, g, threshold) returns FOUND, or the smallest
    f-value it saw that exceeded the threshold, or math.inf.
    """
    initial_state = problem.initial_state()
    threshold = heuristic(initial_state, problem)
    iterations = 0
    nodes_expanded = 0

    def dfs_contour(state, path, state_set, g, threshold):
        nonlocal nodes_expanded
        f = g + heuristic(state, problem)
        
        # If f-cost exceeds threshold, return the exceeded value as the next potential threshold
        if f > threshold:
            return f, None
            
        if problem.is_goal(state):
            return "FOUND", path

        min_exceeded = float('inf')
        nodes_expanded += 1

        for action in problem.get_actions(state):
            successor = problem.result(state, action)
            
            # Linear space: prevent immediate cycles by checking path history
            if successor not in state_set:
                state_set.add(successor)
                res, found_path = dfs_contour(successor, path + [action], state_set, g + 1, threshold)
                state_set.remove(successor)
                
                if res == "FOUND":
                    return "FOUND", found_path
                if res < min_exceeded:
                    min_exceeded = res
                    
        return min_exceeded, None

    while True:
        iterations += 1
        state_set = {initial_state}
        res, path = dfs_contour(initial_state, [], state_set, 0, threshold)
        
        if res == "FOUND":
            return path, nodes_expanded, iterations
        if res == float('inf'):
            # No solution exists
            return None, nodes_expanded, iterations
            
        # Update threshold to the smallest f-value that exceeded the previous threshold
        threshold = res


if __name__ == "__main__":
    # Quick manual check once you have implemented an algorithm:
    from test_grids import EXAMPLE, parse_grid
    from vacuum_world import VacuumWorld
    from heuristics import h2

    grid, start, dirty = parse_grid(EXAMPLE)
    problem = VacuumWorld(grid, start, dirty)
    print(dfs_search(problem))
    print("DFS on the example grid (not optimal, but should find a solution)")
    path, expanded, frontier = astar_search(problem, h2)
    print("A* on the example grid (optimal cost is 14)")
    print("  cost     :", len(path) if path else None)
    print("  expanded :", expanded)
    print("  frontier :", frontier)
    print("  plan     :", path)
